# `4d79712` 证据更正说明

## 原始记录

第二主机原始 `08-final-state.log` 在提交方哈希尚未提供时记录了：

```ini
INDEPENDENT_SECOND_HOST_VERIFY = UNKNOWN
```

`REPORT(4).json` 随后依据目标提交已明确检出且完整门禁通过的判定条件写入了 `PASS`。外部复审指出这是原始包内部的 UNKNOWN/PASS 不一致。

## 后补证据

本包保留原始日志，并另外包含：

- `second-host-identity-comparison-20260905.md`
- `second-host-identity-comparison-20260905.json`

这两份文件记录提交方和第二主机的 `OS_INSTALLATION_ID_SHA256`、`HARDWARE_UUID_SHA256`，且两项均不同。该比较补充了原始日志生成之后的证据，不覆盖原始记录。

## 最终解释

```ini
ORIGINAL_RERUN_STATE = UNKNOWN
POST_RUN_HASH_COMPARISON = PASS_WITH_LIMITATIONS
FINAL_EXTERNAL_STATUS = PASS_WITH_LIMITATIONS
```

限制：提交方侧哈希为后补自述值，没有随本包提供采集命令日志或签名；两台物理机是否属于同一控制方未被排除。因此该状态不等同于强意义的独立第三方复核。
